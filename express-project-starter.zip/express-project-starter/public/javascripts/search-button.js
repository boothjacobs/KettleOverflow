// window.addEventListener("DOMContentLoaded", (event) => {

//     const searchButton = document.getElementById("submit-search");
//     const searchText = document.getElementById("search-bar")



//     console.log(searchText.value)
//     searchText.addEventListener("keyup", (event) => {
//         console.log(event.target.value)
//         const userSearch = event.target.value.toLowerCase();
//         // const questionsTable = document.querySelectorAll()
//     });
// });
